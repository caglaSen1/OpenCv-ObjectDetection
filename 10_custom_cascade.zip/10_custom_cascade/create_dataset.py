'''
With the data set created, create special similar features and make object detection
First create dataset, then create cascade and try to recognize the objects.

1) Data set
    negative images, positive images
2) Download Cascade program
3) Cascade
4) Write the detection algorithm using Cascade
'''

import os
import cv2

# image storage folder
path = "images"

# img size
imgWidth = 180
imgHeight = 120

# Capture, camera settings
cap = cv2.VideoCapture(0)  # 0 - default camera
cap.set(3, 640)  # genişlik
cap.set(4, 480)  # height
cap.set(10, 180)  # camera brightness level

global countFolder


def saveDataFunc():
    global countFolder
    countFolder = 0
    while os.path.exists(path + str(countFolder)):
        countFolder += 1
    os.makedirs(path + str(countFolder))


saveDataFunc()

count = 0
countSave = 0

while True:
    success, frame = cap.read()

    if success:
        # Have to resize because if we had initially set our camera size according to imgWidth and imgHeight, our camera
        # would be too small and I wouldn't be able to see how I was collecting data.
        # That's why we keep the size of the camera large, but then we reduce the size of the images
        frame = cv2.resize(frame, (imgWidth, imgHeight))

        if count % 5 == 0:  # if it's a multiple of 5
            cv2.imwrite(path + str(countFolder) + "/" + str(countSave) + ".png", frame)  # save every 5
            countSave += 1  # increase by 1 every time save
            print(countSave)
        count += 1

        cv2.imshow("Image", frame)

    if(cv2.waitKey(1) & 0xFF == ord("q")):
        break

cap.release()
cv2.destroyAllWindows()

'''
The data set created, download the cascade program:
amin-ahmadi.com/cascade-trainer-gui/

Create a cascade - make adjustments from the exe downloaded:
positive - 100
negative - 74
number of stages - 15
sample width - 36

cascade.xml has been created, write the detection algorithm using cascade
own_cascade_detection.py ...
'''








