import cv2

obj_name = "Pen Tip"
frame_width = 280
frame_height = 360
color = (255, 0, 0)

cap = cv2.VideoCapture(0)
cap.set(3, frame_width)
cap.set(3, frame_height)

def empty(a): pass  # for createTrackBar we have to define it but we will pass it

# trackbar - using this we can change the scale and neighbor values
cv2.namedWindow("Result")  # I always have to specify "Result" for the things I add below to be added on this window
cv2.resizeWindow("Result", frame_width, frame_height + 100)  # If do not write "Result" as wroted above, it will not be added on top.

# "Scale" will change the scale in the detectMultiScale function
cv2.createTrackbar("Scale", "Result", 400, 1000, empty)  # again overwrite "Result", empty method is mandatory but we will pass it
cv2.createTrackbar("Neighbour", "Result", 4, 50, empty)

# cascade classifier
cascade = cv2.CascadeClassifier("cascade.xml")

while True:

    # read img
    success, img = cap.read()

    if success:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # detection params
        scaleVal = 1 + (cv2.getTrackbarPos("Scale", "Result")/1000)  # will vary between 1 and 2
        neighbor = cv2.getTrackbarPos("Neighbor", "Result")

        # detection
        rects = cascade.detectMultiScale(gray, scaleVal, neighbor)

        for (x, y, w, h) in rects:
            cv2.rectangle(img, (x, y), (x+w, y+h), color, 3)
            cv2.putText(img, obj_name, (x, y - 5), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1, color, 2)

        cv2.imshow("Result", img)

    if cv2.waitKey(1) & 0xFF == ord("q"): break
